-- AlterTable
ALTER TABLE "marketPlace" ALTER COLUMN "amount" DROP NOT NULL;

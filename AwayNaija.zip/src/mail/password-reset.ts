const PASSWORD_RESET = (fullName: string, url: string) => ` ${fullName} ${url}`;

export default PASSWORD_RESET;

const WELCOME_EMAIL = (fullName: string, url: string) => `${url} ${fullName}`;

export default WELCOME_EMAIL;
